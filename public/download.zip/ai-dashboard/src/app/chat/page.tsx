'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AppLayout } from '@/components/layout/app-layout';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Bot, User, Send, Sparkles, Loader2, Newspaper, BarChart3, Lightbulb, Target } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const suggestions = [
  { label: 'Generate newsletter draft', icon: Newspaper, prompt: 'Generate newsletter draft' },
  { label: 'Summarize my week', icon: BarChart3, prompt: 'Summarize my week' },
  { label: 'Suggest content ideas', icon: Lightbulb, prompt: 'Suggest content ideas' },
  { label: 'Analyze leads', icon: Target, prompt: 'Analyze leads' },
];

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "👋 Hi! I'm your AI agent. I can help you generate content, analyze your pipeline, summarize your week, and more. Try one of the suggestions below or just ask me anything!",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (prompt: string) => {
    if (!prompt.trim() || isLoading) return;

    const userMsg: Message = { id: crypto.randomUUID(), role: 'user', content: prompt, timestamp: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      const aiMsg: Message = { id: crypto.randomUUID(), role: 'assistant', content: data.response, timestamp: new Date() };
      setMessages((prev) => [...prev, aiMsg]);
    } catch {
      toast.error('Failed to generate response');
    } finally {
      setIsLoading(false);
    }
  };

  const formatContent = (content: string) => {
    // Simple markdown-like rendering
    return content
      .split('\n')
      .map((line, i) => {
        if (line.startsWith('# ')) return `<h1 class="text-lg font-bold mt-3 mb-1">${line.slice(2)}</h1>`;
        if (line.startsWith('## ')) return `<h2 class="text-base font-semibold mt-2 mb-1">${line.slice(3)}</h2>`;
        if (line.startsWith('### ')) return `<h3 class="text-sm font-semibold mt-2 mb-1">${line.slice(4)}</h3>`;
        if (line.startsWith('---')) return '<hr class="my-2 border-border" />';
        if (line.startsWith('- **')) return `<p class="text-sm"><span class="font-semibold">${line.slice(4).replace('**', '')}</span>${line.slice(line.indexOf('**', 4) + 2)}</p>`;
        if (line.startsWith('- ')) return `<p class="text-sm ml-3">• ${line.slice(2)}</p>`;
        if (line.startsWith('> ')) return `<blockquote class="border-l-2 border-teal-400 pl-3 my-1 italic text-muted-foreground text-sm">${line.slice(2)}</blockquote>`;
        if (line.trim() === '') return '<br />';
        return `<p class="text-sm">${line}</p>`;
      })
      .join('');
  };

  return (
    <AppLayout>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex h-[calc(100vh-7rem)] flex-col"
      >
        <div className="mb-4">
          <h1 className="text-2xl font-bold tracking-tight">AI Agent Chat</h1>
          <p className="text-sm text-muted-foreground mt-1">Your AI-powered assistant</p>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto rounded-xl border bg-card p-4 space-y-4">
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn('flex gap-3', msg.role === 'user' ? 'justify-end' : '')}
              >
                {msg.role === 'assistant' && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-900">
                    <Bot className="h-4 w-4 text-teal-700 dark:text-teal-300" />
                  </div>
                )}
                <div
                  className={cn(
                    'max-w-[80%] rounded-2xl px-4 py-3',
                    msg.role === 'user'
                      ? 'bg-teal-600 text-white'
                      : 'bg-muted'
                  )}
                >
                  {msg.role === 'assistant' ? (
                    <div
                      className="prose-sm dark:prose-invert max-w-none [&_h1]:text-base [&_h2]:text-sm [&_h3]:text-sm"
                      dangerouslySetInnerHTML={{ __html: formatContent(msg.content) }}
                    />
                  ) : (
                    <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                  )}
                </div>
                {msg.role === 'user' && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-stone-200 dark:bg-stone-700">
                    <User className="h-4 w-4 text-stone-600 dark:text-stone-300" />
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>

          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-3"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-900">
                <Bot className="h-4 w-4 text-teal-700" />
              </div>
              <div className="rounded-2xl bg-muted px-4 py-3">
                <div className="flex gap-1">
                  <span className="h-2 w-2 animate-bounce rounded-full bg-stone-400" style={{ animationDelay: '0ms' }} />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-stone-400" style={{ animationDelay: '150ms' }} />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-stone-400" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Suggestions */}
        {messages.length <= 1 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {suggestions.map((s) => (
              <button
                key={s.label}
                onClick={() => sendMessage(s.prompt)}
                className="inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium hover:bg-teal-50 hover:border-teal-300 dark:hover:bg-teal-950 transition-colors"
              >
                <s.icon className="h-3.5 w-3.5 text-teal-600" />
                {s.label}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="mt-3 flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage(input);
              }
            }}
            placeholder="Ask me anything..."
            rows={2}
            className="min-h-[48px] resize-none"
          />
          <Button
            size="icon"
            onClick={() => sendMessage(input)}
            disabled={isLoading || !input.trim()}
            className="h-12 w-12 shrink-0 bg-teal-600 hover:bg-teal-700"
          >
            {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
          </Button>
        </div>
      </motion.div>
    </AppLayout>
  );
}
